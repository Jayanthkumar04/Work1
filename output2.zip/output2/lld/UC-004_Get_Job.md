# UC-004 — Get Job  ·  GET /job/{id}

> **Trigger:** 🌐 **HTTP** — 🔵 GET `/job/{id}`  
> **Actor:** API Client  
> **Entry:** `JobController.getJobById()`  

HTTP endpoint GET /job/{id}. Entry: JobController.getJobById(). Public endpoint.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-004` |
| Name | **Get Job** |
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/{id}` |
| Actor | API Client |
| Entry Point | `JobController.getJobById()` |
| Return Type | `Job` |

## 2. Call Chain

`JobController` → `JobService`

## 3. Input Contract

| Parameter | Type | Annotations |
|---|---|---|
| `id` | `Long` | `@PathVariable("id")` |

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.


#### ⚙️ Service Layer

**Step 1** — Invoke service: retrieve — get Job By Id

| Attribute | Value |
|---|---|
| Component | `service` |
| Call | `service.getJobById(id)` |

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber

    participant API_Client as API Client
    participant JobController as JobController
    participant service as service

    API_Client->>JobController: GET /job/{id}
    JobController->>service: Invoke service: retrieve — get Job By Id
    service-->>JobController: return
    JobController->>API_Client: 200 OK — success
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | none |
| Events Published | none |
| External Calls | none |
| Exception Types | none detected |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `Job` |

**Response fields** (`Job`):

| Field | Type | Annotations |
|---|---|---|
| `id` | `Long` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `title` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `company` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `location` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `description` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `salaryRange` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `requiredSkills` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `applications` | `List` | `@OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true)` `@JsonManagedReference` |
| `other` | `Job` | `@Override` |

**HTTP status codes:**

- 200 OK — success
- 500 Internal Server Error — unexpected error

## 9. Side Effects

| Effect | Detail |
|---|---|
| (none detected) |  |

**Pre-conditions:**

- No specific pre-conditions beyond service availability

**Post-conditions:**

- HTTP response sent with status 200 OK — success

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `JobController` | Controller | Handle `GET /job/{id}`. Parse request, call service, return response. |
| ⚙️ `service` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |

### Domain Model Fields

**Job** (`entity`) — package `com.jobboard.dvo`

| Field | Type | Annotations | Required? |
|---|---|---|---|
| `id` 🔑 | `Long` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `title` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `company` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `location` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `description` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `salaryRange` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `requiredSkills` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `applications` | `List` | @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true) @JsonManagedReference | optional |
| `other` | `Job` | @Override | optional |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="jobController" class="<your.package>.JobController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

<bean id="service" class="<your.package>.service">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-004 — "Get Job"
Trigger : GET /job/{id}
Actor   : API Client

Call chain (implement ALL classes):
  JobController → JobService

Entry: JobController.getJobById()

Input:
  Parameters : @PathVariable("id") Long id
  Fields:
  (no request body)

Implementation steps (IN ORDER — implement each one):
   1. [service     ] Invoke service: retrieve — get Job By Id

Business rules (ENFORCE ALL):
  (none)

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : none

Return type: Job
HTTP status: 200 OK — success, 500 Internal Server Error — unexpected error

Side effects: none

Domain types:
  Job (entity):
    id: Long  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    title: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    company: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    location: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    description: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    salaryRange: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    requiredSkills: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    applications: List  @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true) @JsonManagedReference
    other: Job  @Override


Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Include all imports. Write production-quality code.
```

---

