# UC-005 — Get Job  ·  GET /job/search

> **Trigger:** 🌐 **HTTP** — 🔵 GET `/job/search`  
> **Actor:** API Client  
> **Entry:** `JobController.getJobsBySearch()`  

HTTP endpoint GET /job/search. Entry: JobController.getJobsBySearch(). Public endpoint.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-005` |
| Name | **Get Job** |
| Trigger | 🌐 **HTTP** — 🔵 GET `/job/search` |
| Actor | API Client |
| Entry Point | `JobController.getJobsBySearch()` |
| Return Type | `List` |

## 2. Call Chain

`JobController` → `JobService`

## 3. Input Contract

| Parameter | Type | Annotations |
|---|---|---|
| `search` | `String` | `@RequestParam("search")` |

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.


#### ⚙️ Service Layer

**Step 1** — Invoke service: retrieve — get Jobs By Search

| Attribute | Value |
|---|---|
| Component | `service` |
| Call | `service.getJobsBySearch(search)` |

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber

    participant API_Client as API Client
    participant JobController as JobController
    participant service as service

    API_Client->>JobController: GET /job/search
    JobController->>service: Invoke service: retrieve — get Jobs By Search
    service-->>JobController: return
    JobController->>API_Client: 200 OK — success
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | none |
| Events Published | none |
| External Calls | none |
| Exception Types | none detected |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `List` |

**HTTP status codes:**

- 200 OK — success
- 500 Internal Server Error — unexpected error

## 9. Side Effects

| Effect | Detail |
|---|---|
| (none detected) |  |

**Pre-conditions:**

- No specific pre-conditions beyond service availability

**Post-conditions:**

- HTTP response sent with status 200 OK — success

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `JobController` | Controller | Handle `GET /job/search`. Parse request, call service, return response. |
| ⚙️ `service` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="jobController" class="<your.package>.JobController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

<bean id="service" class="<your.package>.service">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-005 — "Get Job"
Trigger : GET /job/search
Actor   : API Client

Call chain (implement ALL classes):
  JobController → JobService

Entry: JobController.getJobsBySearch()

Input:
  Parameters : @RequestParam("search") String search
  Fields:
  (no request body)

Implementation steps (IN ORDER — implement each one):
   1. [service     ] Invoke service: retrieve — get Jobs By Search

Business rules (ENFORCE ALL):
  (none)

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : none

Return type: List
HTTP status: 200 OK — success, 500 Internal Server Error — unexpected error

Side effects: none

Domain types:
  (none)

Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Include all imports. Write production-quality code.
```

---

