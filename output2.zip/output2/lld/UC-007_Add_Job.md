# UC-007 — Add Job  ·  POST /job

> **Trigger:** 🌐 **HTTP** — 🟢 POST `/job`  
> **Actor:** API Client  
> **Entry:** `JobController.addJob()`  

HTTP endpoint POST /job. Entry: JobController.addJob(). Public endpoint.

---

## 1. Use Case Overview

| Property | Value |
|---|---|
| Use Case ID | `UC-007` |
| Name | **Add Job** |
| Trigger | 🌐 **HTTP** — 🟢 POST `/job` |
| Actor | API Client |
| Entry Point | `JobController.addJob()` |
| Return Type | `Job` |

## 2. Call Chain

`JobController` → `JobService`

## 3. Input Contract

| Parameter | Type | Annotations |
|---|---|---|
| `job` | `Job` | `@RequestBody` |

## 4. Implementation Steps

> Each step maps **directly** to code you must write. Steps are ordered by execution sequence within the call chain.


#### ⚙️ Service Layer

**Step 1** — Invoke service: create / persist — add Job

| Attribute | Value |
|---|---|
| Component | `service` |
| Call | `service.addJob(job)` |

## 6. Sequence Diagram

```mermaid
sequenceDiagram
    autonumber

    participant API_Client as API Client
    participant JobController as JobController
    participant service as service

    API_Client->>JobController: POST /job
    JobController->>service: Invoke service: create / persist — add Job
    service-->>JobController: return
    JobController->>API_Client: 200 OK — success
```

## 7. Cross-Cutting Concerns

| Concern | Detail |
|---|---|
| Transaction | none |
| Cache | none |
| Security | none (public) |
| DB Operations | none |
| Events Published | none |
| External Calls | none |
| Exception Types | none detected |

## 8. Output Contract

| Attribute | Value |
|---|---|
| Return Type | `Job` |

**Response fields** (`Job`):

| Field | Type | Annotations |
|---|---|---|
| `id` | `Long` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `title` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `company` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `location` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `description` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `salaryRange` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `requiredSkills` | `String` | `@Id` `@GeneratedValue(strategy=GenerationType.IDENTITY)` |
| `applications` | `List` | `@OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true)` `@JsonManagedReference` |
| `other` | `Job` | `@Override` |

**HTTP status codes:**

- 200 OK — success
- 500 Internal Server Error — unexpected error

## 9. Side Effects

| Effect | Detail |
|---|---|
| (none detected) |  |

**Pre-conditions:**

- No specific pre-conditions beyond service availability

**Post-conditions:**

- HTTP response sent with status 200 OK — success

## 10. Code Generation Guide

### Class Responsibilities

| Class | Layer | Responsibility |
|---|---|---|
| 🌐 `JobController` | Controller | Handle `POST /job`. Parse request, call service, return response. |
| ⚙️ `service` | Service | Business logic and orchestration. Coordinates DAO / persistence calls. |

### Domain Model Fields

**Job** (`entity`) — package `com.jobboard.dvo`

| Field | Type | Annotations | Required? |
|---|---|---|---|
| `id` 🔑 | `Long` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `title` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `company` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `location` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `description` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `salaryRange` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `requiredSkills` 🔑 | `String` | @Id @GeneratedValue(strategy=GenerationType.IDENTITY) | optional |
| `applications` | `List` | @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true) @JsonManagedReference | optional |
| `other` | `Job` | @Override | optional |

### Legacy XML Bean Wiring

For XML-configured Spring projects, register these beans in `applicationContext.xml`:

```xml
<bean id="jobController" class="<your.package>.JobController">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

<bean id="service" class="<your.package>.service">
    <!-- inject dependencies via constructor-arg or property -->
</bean>

```

### LLM Implementation Prompt

Paste the block below directly into your LLM to generate implementation code for this use case:

```
Implement UC-007 — "Add Job"
Trigger : POST /job
Actor   : API Client

Call chain (implement ALL classes):
  JobController → JobService

Entry: JobController.addJob()

Input:
  Parameters : @RequestBody Job job
  Fields:
  (no request body)

Implementation steps (IN ORDER — implement each one):
   1. [service     ] Invoke service: create / persist — add Job

Business rules (ENFORCE ALL):
  (none)

Cross-cutting:
  Transaction : none
  Cache       : none
  Security    : none
  Exceptions  : none

Return type: Job
HTTP status: 200 OK — success, 500 Internal Server Error — unexpected error

Side effects: none

Domain types:
  Job (entity):
    id: Long  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    title: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    company: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    location: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    description: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    salaryRange: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    requiredSkills: String  @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    applications: List  @OneToMany(mappedBy = "job", cascade = CascadeType.ALL, orphanRemoval = true) @JsonManagedReference
    other: Job  @Override


Generate complete, compilable Java Spring code.
Follow existing project patterns. Include all imports.
Implement every step above. Include all imports. Write production-quality code.
```

---

